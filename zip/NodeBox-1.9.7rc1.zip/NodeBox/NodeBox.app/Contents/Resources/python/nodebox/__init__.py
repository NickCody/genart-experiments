__version__='1.9.7rc1'

def get_version():
    return __version__